package sample;

import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;

import java.awt.*;

public class Controller {

    @FXML
    private TextField username_login;

    @FXML
    private PasswordField password_login;

    @FXML
    private TextField username_reg;

    @FXML
    private TextField password_reg;

    String username_reg1;
    String password_reg1;

    String username_reg2;
    String password_reg2;

    public void set_information()
    {

        username_reg1 =  username_reg.getText();
        password_reg1 =  password_reg.getText();


    }

    public String get_usename_reg1()
    {
        return username_reg2;
    }



    public String get_password_reg()
    {
        return password_reg2;
    }



    public  void comp_information()
    {
        if (username_login.getText() == get_usename_reg1() && password_login.getText() == get_password_reg())
        {
            System.out.println("this is ok");
        }
        else
        {
            System.out.println("this is not ok");
        }
    }

    public void set_usename_reg1(String username_reg1)
    {
        this.username_reg1 = username_reg2;
    }

    public void set_password_reg1(String password_reg1)
    {
        this.password_reg1 = password_reg2;
    }
}
