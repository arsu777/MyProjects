/**
 * Created by Mahdy on Oct-22-18.
 */
import java.io.IOException;
//import java.util.Random;
import java.util.Scanner;

public class Maze {

    public static void main(String[] args) throws IOException {
        int i = 0, j = 0;
        Scanner m = new Scanner(System.in);
        System.out.println("enter: ");
        //String input = m.next();
        String[][] matrix =
                {
                        {"@", "#", " ", "#", " "},
                        {" ", " ", "#", " ", " "},
                        {" ", " ", " ", " ", "#"},
                        {"#", " ", "#", " ", " "},
                        {" ", "#", " ", "#", " "},

                };

        for (int g = 0; g < matrix.length; g++) {
            for (int k = 0; k < matrix.length; k++) {

                System.out.print(matrix[g][k] + " ");
            }

            System.out.println("");
        }

        while (true) {

//            for (i = 0; i < matrix.length-1; i++) {
//                for (j = 0; j < matrix.length-1; j++)
//                    if (matrix[i][j].equals("#")) {
//                        break;
//                    }
//                if (matrix[i][j].equals("#")) {
//                    break;
//                }
//            }
            String d = m.nextLine();
            if (d.contains("a")) {

                matrix[i][j] = " ";

                if (j < 5 && i < 5 && !matrix[i][j - 1].equals("#")) {
                    j = j - 1;
                    matrix[i][j] = "@";
                    Runtime.getRuntime().exec("cmd /c cls");
                    for (int g = 0; g < matrix.length - 1; g++) {
                        for (int h = 0; h < matrix.length - 1; h++) {

                            System.out.print(matrix[g][h] + " ");
                        }

                        System.out.println("");// This thing has to be for the first 'for' not second!
                    }
                    System.out.println("____________________________");
                } else {
                    System.out.println("you cant move!!!  :-(");
                }


            }
            if (d.contains("d")) {

                matrix[i][j] = " ";


                if (j < 5 && i < 5 && !matrix[i][j + 1].equals("#")) {
                    j = j + 1;
                    matrix[i][j] = "@";
                    Runtime.getRuntime().exec("cmd /c cls");
                    for (int g = 0; g < matrix.length - 1; g++) {
                        for (int h = 0; h < matrix.length - 1; h++) {

                            System.out.print(matrix[g][h] + " ");
                        }

                        System.out.println("");// This thing has to be for the first 'for' not second!
                    }
                    System.out.println("____________________________");
                } else {
                    System.out.println("you cant move!!!  :-(");
                }


            }
            if (d.contains("s")) {

                matrix[i][j] = " ";

                if (j < 5 && i < 5 && !matrix[i + 1][j].equals("#")) {
                    i = i + 1;
                    matrix[i][j] = "@";
                    Runtime.getRuntime().exec("cmd /c cls");
                    for (int g = 0; g < matrix.length - 1; g++) {
                        for (int h = 0; h < matrix.length - 1; h++) {

                            System.out.print(matrix[g][h] + " ");
                        }

                        System.out.println("");
                    }
                    System.out.println("____________________________");
                } else {
                    System.out.println("you cant move!!!  :-(");
                }

            }
            if (d.contains("w")) {

                matrix[i][j] = " ";

                if (j < 5 && i < 5 && !matrix[i - 1][j].equals("#")) {
                    i = i - 1;
                    matrix[i][j] = "@";
                    Runtime.getRuntime().exec("cmd /c cls");
                    for (int g = 0; g < matrix.length - 1; g++) {
                        for (int h = 0; h < matrix.length - 1; h++) {

                            System.out.print(matrix[g][h] + " ");
                        }

                        System.out.println("");
                    }
                    System.out.println("____________________________");
                } else {
                    System.out.println("you cant move!!!  :-(");
                }


            }

        }
    }

}
